export interface LineItem {
    label: string;
    quantity: number; 
}